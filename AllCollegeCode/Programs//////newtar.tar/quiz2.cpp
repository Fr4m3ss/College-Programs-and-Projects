#include <iostream>
using namespace std;

int main()
{
int input1;
int input2;

cout<<"input 2 numbers"<<endl;
cin>>input1>>input2;

	if((input1%input2)==0)
	{
         cout<<"Divides"<<endl;
	}	
	else
	{
	cout<<"Equal"<<endl;
	}
	return 0;
}
