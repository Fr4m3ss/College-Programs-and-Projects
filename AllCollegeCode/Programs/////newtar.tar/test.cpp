//Frankie Messina
#include <iostream>
using namespace std;
int main()
{
	cout<<"Hello World"<<endl;

	int val = 16;
	double num = 2.75, gpa;	
	gpa = 3.4;

	cout<<"Val= "<<val<<endl;
	cout<<"Num= "<<num<<" GPA= "<<gpa<<endl;	
	
	return 0;
}

