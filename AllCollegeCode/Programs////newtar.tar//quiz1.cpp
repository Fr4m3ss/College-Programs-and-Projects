#include<iostream>
using namespace std;
int main()
{
double num1;
double num2;
cout<<"Please input 2 doubles: "<<endl;
cin>>num1>>num2;

cout<<"The difference between your numbers is: "<< (num1-=num2)<<endl;

return 0;

}
